package nit.ws.and;

import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/sinfo")
public class StuInfo {
	static ArrayList<Student> students= new ArrayList<Student>();
	
	@Path("/insert/{name}/{gender}/{email}/{mno}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String insertStudentInfo(
			@PathParam("name") String name,
			@PathParam("gender") String gender,
			@PathParam("email") String email,
			@PathParam("mno") String mno)
	{
System.out.println(name+"\t"+gender+"\t"+
				email+"\t"+mno);
Student s = new Student( );
s.setName(name);
s.setGender(gender);
s.setEmail(email);
s.setMobileno(mno);
students.add(s);
return "{\"status\":\"success\"}";		
	}
	
	@Path("/read")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Students readStuInfo( ) {
		Students s = new Students();
		s.setStudents(students);
		return s;
	}

}
